<?php
session_start();
include '../config.php';
include '../session.php';

if (!isAdmin()) {
    header("Location: ../login.php");
    exit();
}

if (isset($_GET['id'])) {
    $id_user = $_GET['id'];

    // Persiapkan statement untuk menghapus user
    $stmt = $koneksi->prepare("DELETE FROM users WHERE id_user = ?");
    $stmt->bind_param("i", $id_user);

    if ($stmt->execute()) {
        echo "<script>alert('User berhasil dihapus!'); window.location.href='../register.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus user!'); window.location.href='../register.php';</script>";
    }
} else {
    echo "<script>alert('ID User tidak valid!'); window.location.href='../register.php';</script>";
}
?>
