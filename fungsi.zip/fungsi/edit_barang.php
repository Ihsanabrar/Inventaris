<?php
include 'navbar.phpconfig.php';

$alert = ""; // Variabel untuk menyimpan notifikasi

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $koneksi->prepare("SELECT * FROM barang WHERE id_barang = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id_barang'];
    $nama_barang = $_POST['nama_barang'];
    $harga = $_POST['harga_barang'];
    $stok = $_POST['stok'];

    // Menggunakan prepared statement untuk menghindari SQL Injection
    $stmt = $koneksi->prepare("UPDATE barang SET nama_barang=?, harga_barang=?, stok=? WHERE id_barang=?");
    $stmt->bind_param("ssii", $nama_barang, $harga, $stok, $id);

    if ($stmt->execute()) {
        $stmt->close();
        $koneksi->close();
        
        // Mengatur notifikasi sukses di JavaScript
        echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    let alertBox = document.createElement('div');
                    alertBox.innerHTML = 'Data berhasil diperbarui!';
                    alertBox.style.position = 'fixed';
                    alertBox.style.top = '20px';
                    alertBox.style.left = '50%';
                    alertBox.style.transform = 'translateX(-50%)';
                    alertBox.style.backgroundColor = '#4CAF50';
                    alertBox.style.color = 'white';
                    alertBox.style.padding = '10px 20px';
                    alertBox.style.borderRadius = '5px';
                    alertBox.style.boxShadow = '0px 4px 6px rgba(0, 0, 0, 0.1)';
                    document.body.appendChild(alertBox);
                    
                    setTimeout(function() {
                        alertBox.style.display = 'none';
                        window.location.href = 'navbar.phpindex.php';
                    }, 500);
                });
              </script>";
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Barang</title>
    <link rel="stylesheet" href="navbar.phpstyle.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container">
        <h1>Edit Barang</h1>
        <form method="POST" class="form-tambah">
            <input type="hidden" name="id_barang" value="<?php echo htmlspecialchars($row['id_barang']); ?>">
            <div class="form-group">
                <label for="nama_barang">Nama Barang: </label>
                <input type="text" id="nama_barang" name="nama_barang" value="<?php echo htmlspecialchars($row['nama_barang']); ?>" required>
            </div>
            <div class="form-group">
                <label for="harga_barang">Harga Barang: </label>
                <input type="number" id="harga_barang" name="harga_barang" value="<?php echo htmlspecialchars($row['harga_barang']); ?>" required>
            </div>
            <div class="form-group">
                <label for="stok">Stok Barang: </label>
                <input type="number" id="stok" name="stok" value="<?php echo htmlspecialchars($row['stok']); ?>" required>
            </div>
            <div class="form-actions">
                <button type="submit" class="btn-simpan">Simpan</button>
                <a href="navbar.phpindex.php" class="btn-batal">Batal</a>
            </div>
        </form>
    </div>
</body>
</html>
