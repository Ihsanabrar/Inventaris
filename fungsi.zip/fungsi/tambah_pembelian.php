<?php
include '../config.php';
session_start();
include '../session.php';

// Ambil data id_user dan name dari tabel users
$query_users = $koneksi->query("SELECT id_user, name FROM users");
$users = $query_users->fetch_all(MYSQLI_ASSOC);

// Ambil data id_supplier dan nama_supplier dari tabel supplier
$query_suppliers = $koneksi->query("SELECT id_supplier, nama_supplier FROM supplier");
$suppliers = $query_suppliers->fetch_all(MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_user = $_POST['id_user'];
    $id_supplier = $_POST['id_supplier'];
    $tanggal_pembelian = $_POST['tanggal_pembelian'];

    // Insert data baru
    $stmt = $koneksi->prepare("INSERT INTO pembelian (id_user, id_supplier, tanggal_pembelian) VALUES (?, ?, ?)");
    $stmt->bind_param("iis", $id_user, $id_supplier, $tanggal_pembelian);

    if ($stmt->execute()) {
        // Reset AUTO_INCREMENT jika diperlukan
        $reset_query = "ALTER TABLE pembelian AUTO_INCREMENT = 1";
        $koneksi->query($reset_query);

        header("Location: ../pembelian.php");
        exit();
    } else {
        echo "Gagal menambahkan data.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Pembelian</title>
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
    /* Form Tambah Pembelian */
        .form-tambah {
            background-color: #ffffff;
            max-width: 600px;
            margin: 40px auto;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
            transition: box-shadow 0.3s ease;
        }

        .form-tambah:hover {
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #2c3e50;
        }

        .form-group select,
        .form-group input[type="datetime-local"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 16px;
            transition: border 0.3s;
        }

        .form-group select:focus,
        .form-group input[type="datetime-local"]:focus {
            border-color: #2980b9;
            outline: none;
        }

        /* Tombol Simpan dan Batal */
        .btn-simpan,
        .btn-batal {
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s, transform 0.2s;
            margin-right: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .btn-simpan {
            background-color: #27ae60;
        }

        .btn-simpan:hover {
            background-color: #1e8449;
            transform: translateY(-2px);
        }

        .btn-batal {
            background-color: #e74c3c;
        }

        .btn-batal:hover {
            background-color: #c0392b;
            transform: translateY(-2px);
        }

        /* Header */
        .dashboard-header {
            margin-bottom: 40px;
            padding: 20px;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        }

        .dashboard-header h1 {
            color: #2c3e50;
            font-size: 28px;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .dashboard-header p {
            color: #7f8c8d;
            margin: 5px 0 0;
            font-size: 16px;
        }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="dashboard-container">
    <div class="dashboard-header">
        <h1><i class="fas fa-cart-plus"></i> Tambah Pembelian</h1>
        <p>Form untuk menambahkan data pembelian baru</p>
    </div>

    <div class="form-tambah">
        <form method="POST" action="">
            <div class="form-group">
                <label for="id_user"><i class="fas fa-user"></i> Pilih User</label>
                <select id="id_user" name="id_user" required>
                    <option value="">-- Pilih User --</option>
                    <?php foreach ($users as $user): ?>
                        <option value="<?= htmlspecialchars($user['id_user']) ?>">
                            <?= htmlspecialchars($user['name']) ?> <!-- Tampilkan name, bukan id_user -->
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="id_supplier"><i class="fas fa-truck"></i> Pilih Supplier</label>
                <select id="id_supplier" name="id_supplier" required>
                    <option value="">-- Pilih Supplier --</option>
                    <?php foreach ($suppliers as $supplier): ?>
                        <option value="<?= htmlspecialchars($supplier['id_supplier']) ?>">
                            <?= htmlspecialchars($supplier['nama_supplier']) ?> <!-- Tampilkan nama_supplier, bukan id_supplier -->
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="tanggal_pembelian"><i class="fas fa-calendar-alt"></i> Tanggal Pembelian</label>
                <input type="date" id="tanggal_pembelian" name="tanggal_pembelian" required>
            </div>
            <div class="form-group">
                <button type="submit" class="btn-simpan"><i class="fas fa-save"></i> Simpan</button>
                <a href="../pembelian.php" class="btn-batal"><i class="fas fa-times"></i> Batal</a>
            </div>
        </form>
    </div>
</div>
</body>
</html>