<?php
include '../config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    $nama_barang = $_POST['nama_barang'];
    $harga = $_POST['harga_barang'];
    $stok = $_POST['stok'];

    $query ="INSERT INTO barang (nama_barang, harga_barang, stok) VALUES ('$nama_barang','$harga','$stok')";
    if ($koneksi->query($query) === TRUE ){ 
        echo '
        <!DOCTYPE html>
        <html>
        <head>
            <title>Redirecting...</title>
            <link rel="stylesheet" href="../style.css">
        </head>
        <body>
            <div class="notification">Berhasil ditambahkan</div>
            <script>
                setTimeout(function() {
                    window.location.href = "../index.php";
                }, 1500);
            </script>
        </body>
        </html>';
        exit();
    } else {
        echo "error" . $query . "<br>" . $koneksi->error;
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Barang</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
<form method="POST" class="form-tambah">
            <div class="form-group">
                <label for="nama_barang">Nama Barang: </label>
                <input type="text" id="nama_barang" name="nama_barang" required>
            </div>
            <div class="form-group">
                <label for="harga_barang">Harga Barang: </label>
                <input type="number" id="harga_barang" name="harga_barang" required>
            </div>
            <div class="form-group">
                <label for="stok">Stok Barang: </label>
                <input type="number" id="stok" name="stok" required>
            </div>
            <div class="form-actions">
                <button type="submit" class="btn-simpan">Simpan</button>
                <a href="../index.php" class="btn-batal">Batal</a>
            </div>
        </form>
</body>
</html>