<?php
session_start();
include '../config.php';


// Pastikan parameter id_supplier tersedia
if (!isset($_GET['id'])) {
    header("Location: ../supplier.php");
    exit();
}

$id_supplier = intval($_GET['id']);

// Ambil data supplier berdasarkan id
$query = "SELECT * FROM supplier WHERE id_supplier = $id_supplier";
$result = mysqli_query($koneksi, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    echo "<script>alert('Supplier tidak ditemukan!'); window.location='../supplier.php';</script>";
    exit();
}

$supplier = mysqli_fetch_assoc($result);

// Proses update supplier ketika tombol simpan ditekan
if (isset($_POST['simpan'])) {
    $nama_supplier = $_POST['nama_supplier'];
    $alamat = $_POST['alamat'];
    $no_hp = $_POST['no_hp'];

    $update_query = "UPDATE supplier SET nama_supplier = '$nama_supplier', alamat = '$alamat', no_hp = '$no_hp' WHERE id_supplier = $id_supplier";
    
    if (mysqli_query($koneksi, $update_query)) {
        echo "<script>
                alert('Berhasil diubah!');
                window.location='../supplier.php';
              </script>";
        exit();
    } else {
        echo "<script>alert('Gagal mengubah data!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Supplier</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        /* Desain khusus untuk halaman edit supplier */
        .edit-supplier-container {
            max-width: 600px;
            margin: 40px auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        .edit-supplier-container h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #2c3e50;
        }
        .edit-supplier-container .form-group {
            margin-bottom: 20px;
        }
        .edit-supplier-container label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #2c3e50;
        }
        .edit-supplier-container input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        .edit-supplier-container input:focus {
            border-color: #2980b9;
            outline: none;
            box-shadow: 0 0 0 3px rgba(41, 128, 185, 0.1);
        }
        .edit-supplier-container button {
            width: 100%;
            padding: 12px;
            background-color: #27ae60;
            color: #fff;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.2s;
            margin-bottom: 10px;
        }
        .edit-supplier-container button:hover {
            background-color: #1e8449;
            transform: translateY(-2px);
        }
        /* Styling khusus untuk tombol kembali */
        .edit-supplier-container .btn-batal {
            background-color: #e74c3c;
        }
        .edit-supplier-container .btn-batal:hover {
            background-color: #c0392b;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="edit-supplier-container">
        <h2>Edit Supplier</h2>
        <form method="POST" action="">
            <div class="form-group">
                <label for="nama_supplier">Nama Supplier:</label>
                <input type="text" id="nama_supplier" name="nama_supplier" value="<?php echo $supplier['nama_supplier']; ?>" required>
            </div>
            <div class="form-group">
                <label for="alamat">Alamat:</label>
                <input type="text" id="alamat" name="alamat" value="<?php echo $supplier['alamat']; ?>" required>
            </div>
            <div class="form-group">
                <label for="no_hp">No HP:</label>
                <input type="text" id="no_hp" name="no_hp" value="<?php echo $supplier['no_hp']; ?>" required>
            </div>
            <!-- Tombol Simpan -->
            <button type="submit" name="simpan">Simpan</button>
            <!-- Tombol Kembali -->
            <button type="button" onclick="window.location='../supplier.php'" class="btn-batal">Kembali</button>
        </form>
    </div>
</body>
</html>

<?php
// Tutup koneksi
mysqli_close($koneksi);
?>
