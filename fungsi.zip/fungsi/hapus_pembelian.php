<?php
include '../config.php';

if (isset($_GET['id'])) {
    $id_pembelian = $_GET['id'];

    // Hapus langsung pembelian, detail_pembelian akan otomatis ikut terhapus
    $stmt = $koneksi->prepare("DELETE FROM pembelian WHERE id_pembelian = ?");
    $stmt->bind_param("i", $id_pembelian);
    $stmt->execute();
    $stmt->close();

    header("Location: ../pembelian.php?status=sukses");
    exit();
} else {
    header("Location: ../pembelian.php?status=gagal");
    exit();
}
?>
