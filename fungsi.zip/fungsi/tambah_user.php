<?php
session_start();
include '../config.php';
include '../session.php';

if (!isAdmin()) {
    header("Location: ../login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $name = $_POST['name'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['level'];

    // Validasi username unik
    $stmt = $koneksi->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $_SESSION['error'] = "Username sudah digunakan!";
    } else {
        $stmt = $koneksi->prepare("INSERT INTO users (username, name, password, level) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $username, $name, $password, $role);

        if ($stmt->execute()) {
            // Tampilkan notifikasi dan redirect dengan JavaScript
            echo '
            <!DOCTYPE html>
            <html lang="id">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Redirecting...</title>
                <link rel="stylesheet" href="../style.css">
                <style>
                    .notification {
                        position: fixed;
                        top: 20px;
                        left: 50%;
                        transform: translateX(-50%);
                        padding: 15px 30px;
                        background-color: #4CAF50;
                        color: white;
                        border-radius: 4px;
                        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
                        z-index: 1000;
                        animation: fadeOut 1s ease-out;
                    }

                    @keyframes fadeOut {
                        from { opacity: 1; }
                        to { opacity: 0; }
                    }
                </style>
            </head>
            <body>
                <div class="notification">Berhasil Terdaftar!</div>
                <script>
                    setTimeout(function() {
                        window.location.href = "../register.php";
                    }, 1000); // Redirect setelah 1 detik
                </script>
            </body>
            </html>';
            exit();
        } else {
            $_SESSION['error'] = "Gagal membuat akun!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Pengguna</title>
    <link rel="stylesheet" href="../style.css">
    <style>
    body {
        font-family: 'Arial', sans-serif;
        background-color: #f4f4f9;
        margin: 0;
        padding: 0;
    }

    .container {
        max-width: 800px;
        margin: 50px auto;
        padding: 20px;
        background-color: #fff;
        box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        border-radius: 10px;
    }

    h1 {
        text-align: center;
        color: #333;
        margin-bottom: 20px;
    }

    h2 {
        color: #333;
        margin-top: 30px;
        margin-bottom: 15px;
    }

    .form-register {
        display: flex;
        flex-direction: column;
        gap: 15px;
    }

    .form-group {
        display: flex;
        flex-direction: column;
        gap: 5px;
    }

    .form-group label {
        font-weight: bold;
        color: #555;
    }

    .form-group input,
    .form-group select {
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 5px;
        font-size: 16px;
    }

    .form-group input:focus,
    .form-group select:focus {
        border-color: #007bff;
        outline: none;
    }

    .user-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .user-table th,
    .user-table td {
        padding: 12px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    .user-table th {
        background-color: #f8f9fa;
        font-weight: bold;
        color: #333;
    }

    .user-table tr:hover {
        background-color: #f1f1f1;
    }
    </style>
</head>

<body>
    <?php include 'navbar.php'; ?>
    <div class="container">
        <h1>Tambah Pengguna Baru</h1>
        <form method="POST" class="form-register">
            <div class="form-group">
                <label for="username">Nama:</label>
                <input type="text" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <label for="level">Pilih Role:</label>
                <select id="level" name="level" required>
                    <option value="admin">Admin</option>
                    <option value="petugas">Petugas</option>
                </select>
            </div>
            <button type="submit" class="btn-simpan">Daftar</button>
                <a href="../register.php" class="btn-batal">Kembali</a>
        </form>
</body>

</html>