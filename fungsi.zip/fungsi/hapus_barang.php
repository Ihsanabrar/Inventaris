<?php
include '../config.php';
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "DELETE FROM barang WHERE id_barang= $id";
    if($koneksi->query($query) === TRUE){
        $check = $koneksi->query("SELECT COUNT(*) as total FROM barang");
        $row = $check->fetch_assoc();
        if ($row['total'] == 0){
            $koneksi->query("ALTER TABLE barang AUTO_INCREMENT = 1");
        }
        header ("Location: ../index.php");
    }else{
        echo "Error" . $query . "<br>" . $koneksi->error;
    }
}



?>