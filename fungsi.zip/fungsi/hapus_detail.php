<?php
include '../config.php';


$id = $_GET['id'];
$pembelian_id = $_GET['pembelian_id'];

$stmt = $koneksi->prepare("DELETE FROM detail_pembelian WHERE id_pembelian_detail = ?");
$stmt->bind_param("i", $id);
$stmt->execute();

header("Location: ../detail_pembelian.php?id=$pembelian_id");
exit();
?>