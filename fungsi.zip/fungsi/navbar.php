
<nav class="navbar">
    <div class="navbar-brand">INV</div>
    <ul class="navbar-nav">
        <li><a href="index.php">Manajemen Barang</a></li>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="pembelian.php">Pembelian</a></li>
        <li><a href="supplier.php">Supplier</a></li>
        <li><a href="laporan_inventaris.php">Laporan</a></li>
        <li>
            <?php
            // Cek apakah session sudah ada dan apakah role adalah 'admin'
            if (isset($_SESSION['level']) && $_SESSION['level'] == 'admin') {
                echo '<a href="register.php">User</a>';
            }
            ?>
        </li>
        <li><a href="logout.php">Keluar</a></li>
    </ul>
</nav>
