<?php
// Mulai session dan koneksi ke database
session_start();
include '../config.php';

// Cek apakah user memiliki akses
if (!isset($_SESSION['level']) || ($_SESSION['level'] != 'admin' && $_SESSION['level'] != 'petugas')) {
    header("Location: ../login.php");
    exit();
}

// Query untuk mendapatkan data supplier
$query = "SELECT * FROM supplier";
$result = mysqli_query($koneksi, $query);

// Proses menambahkan supplier
if (isset($_POST['submit'])) {
    $nama_supplier = $_POST['nama_supplier'];
    $alamat = $_POST['alamat'];
    $no_hp = $_POST['no_hp'];

    $insert_query = "INSERT INTO supplier (nama_supplier, alamat, no_hp) 
                     VALUES ('$nama_supplier', '$alamat', '$no_hp')";

    if (mysqli_query($koneksi, $insert_query)) {
        echo "<script>alert('Supplier berhasil ditambahkan!');</script>";
        header("Location: ../supplier.php");
    } else {
        echo "<script>alert('Terjadi kesalahan, coba lagi.');</script>";
    }
}

// Proses menghapus supplier
if (isset($_GET['hapus'])) {
    $id_supplier = $_GET['hapus'];
    $delete_query = "DELETE FROM supplier WHERE id_supplier = $id_supplier";

    if (mysqli_query($koneksi, $delete_query)) {
        echo "<script>alert('Supplier berhasil dihapus!');</script>";
        header("Location: ../supplier.php");
    } else {
        echo "<script>alert('Terjadi kesalahan, coba lagi.');</script>";
    }
}

// Proses mengedit supplier
if (isset($_POST['edit'])) {
    $id_supplier = $_POST['id_supplier'];
    $nama_supplier = $_POST['nama_supplier'];
    $alamat = $_POST['alamat'];
    $no_hp = $_POST['no_hp'];

    $update_query = "UPDATE supplier SET nama_supplier = '$nama_supplier', alamat = '$alamat', no_hp = '$no_hp' 
                     WHERE id_supplier = $id_supplier";

    if (mysqli_query($koneksi, $update_query)) {
        echo "<script>alert('Supplier berhasil diupdate!');</script>";
        header("Location: ../supplier.php");
    } else {
        echo "<script>alert('Terjadi kesalahan, coba lagi.');</script>";
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TAMBAH SUPPLIER</title>
    <link rel="stylesheet" href="../style.css">
</head>

<body>
    <?php include 'navbar.php'; ?>
    <div class="supplier-container">
        <header>
            <h1>Kelola Supplier</h1>
        </header>

        <!-- Form Tambah Supplier -->
        <section class="supplier-form-container">
            <h2><?php echo isset($_GET['edit']) ? 'Edit Supplier' : 'Tambah Supplier Baru'; ?></h2>
            <form method="POST" action="../supplier.php">
                <?php if (isset($_GET['edit'])) { 
                $edit_id = $_GET['edit'];
                $edit_query = "SELECT * FROM supplier WHERE id_supplier = $edit_id";
                $edit_result = mysqli_query($koneksi, $edit_query);
                $edit_row = mysqli_fetch_assoc($edit_result);
            ?>
                <input type="hidden" name="id_supplier" value="<?php echo $edit_row['id_supplier']; ?>">
                <?php } ?>
                <label for="nama_supplier">Nama Supplier</label>
                <input type="text" name="nama_supplier"
                    value="<?php echo isset($edit_row) ? $edit_row['nama_supplier'] : ''; ?>" required>

                <label for="alamat">Alamat</label>
                <input type="text" name="alamat" value="<?php echo isset($edit_row) ? $edit_row['alamat'] : ''; ?>"
                    required>

                <label for="no_hp">No HP</label>
                <input type="text" name="no_hp" value="<?php echo isset($edit_row) ? $edit_row['no_hp'] : ''; ?>"
                    required>

                <button type="submit" name="<?php echo isset($_GET['edit']) ? 'edit' : 'submit'; ?>">
                        <?php echo isset($_GET['edit']) ? 'Update Supplier' : 'Tambah Supplier'; ?>
                </button>
                <a href="../supplier.php" class="btn-batal">Batal</a>
            </form>
        </section>
        
    </div>
</body>

</html>